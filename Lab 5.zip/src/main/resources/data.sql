INSERT INTO COURSE(name, description, price) VALUES
('Detox Meal Plan', '7-day clean eating program focused on whole foods.', 19900),
('Keto Basics', 'Introductory course to ketogenic nutrition.', 24900),
('Balanced Plate', 'Everyday healthy eating for busy people.', 14900);

INSERT INTO OPERATOR(name, surname, department) VALUES
('Aruzhan','Saparova','IT'),
('Dias','Nurpeis','Praja'),
('Mira','Akhmetova','Marketing'),
('Rustam','Omarov','Marketing');
