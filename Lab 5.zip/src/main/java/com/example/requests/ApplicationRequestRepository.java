package com.example.requests;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApplicationRequestRepository extends JpaRepository<ApplicationRequest, Long> {}
