package com.example.requests;

import jakarta.persistence.*;
import lombok.*;
import java.util.*;

@Entity @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ApplicationRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userName;
    @Column(length = 2000)
    private String commentary;
    private String phone;
    private boolean handled; // processed or not

    @ManyToOne(optional = false)
    private Course course;

    @ManyToMany
    @JoinTable(
        name = "request_operator",
        joinColumns = @JoinColumn(name = "request_id"),
        inverseJoinColumns = @JoinColumn(name = "operator_id")
    )
    private Set<Operator> operators = new LinkedHashSet<>();
}
