package com.example.requests;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Controller
@RequiredArgsConstructor
@RequestMapping("/requests")
public class RequestController {
    private final ApplicationRequestRepository requestRepo;
    private final CourseRepository courseRepo;
    private final OperatorRepository operatorRepo;

    @GetMapping
    public String list(Model model){
        model.addAttribute("requests", requestRepo.findAll());
        return "requests";
    }

    @GetMapping("/new")
    public String createForm(@RequestParam(value = "courseId", required = false) Long courseId, Model model){
        ApplicationRequest r = new ApplicationRequest();
        r.setHandled(false);
        if (courseId != null) {
            courseRepo.findById(courseId).ifPresent(r::setCourse);
        }
        model.addAttribute("request", r);
        model.addAttribute("courses", courseRepo.findAll());
        return "request_form";
    }

    @PostMapping
    public String save(@ModelAttribute ApplicationRequest req, RedirectAttributes ra){
        // Ensure course is persistent
        Course c = courseRepo.findById(req.getCourse().getId()).orElseThrow();
        req.setCourse(c);
        req.setHandled(false);
        req.setOperators(new LinkedHashSet<>());
        requestRepo.save(req);
        ra.addFlashAttribute("msg", "Request submitted");
        return "redirect:/requests";
    }

    @GetMapping("/{id}")
    public String view(@PathVariable Long id, Model model){
        ApplicationRequest r = requestRepo.findById(id).orElseThrow();
        model.addAttribute("request", r);
        return "request_view";
    }

    @GetMapping("/{id}/process")
    public String process(@PathVariable Long id, Model model, RedirectAttributes ra){
        ApplicationRequest r = requestRepo.findById(id).orElseThrow();
        if (r.isHandled()){
            ra.addFlashAttribute("msg", "This request is already processed.");
            return "redirect:/requests/" + id;
        }
        model.addAttribute("request", r);
        model.addAttribute("operators", operatorRepo.findAll());
        return "operators_select";
    }

    @PostMapping("/{id}/assign")
    public String assign(@PathVariable Long id, @RequestParam List<Long> operatorIds, RedirectAttributes ra){
        ApplicationRequest r = requestRepo.findById(id).orElseThrow();
        if (r.isHandled()){
            ra.addFlashAttribute("msg", "Already processed; cannot assign more operators.");
            return "redirect:/requests/" + id;
        }
        Set<Operator> selected = new LinkedHashSet<>(operatorRepo.findAllById(operatorIds));
        r.getOperators().addAll(selected);
        r.setHandled(true); // lock after first assignment
        requestRepo.save(r);
        ra.addFlashAttribute("msg", "Operators assigned and request marked as processed.");
        return "redirect:/requests/" + id;
    }

    @PostMapping("/{id}/removeOperator")
    public String removeOperator(@PathVariable Long id, @RequestParam Long operatorId, RedirectAttributes ra){
        ApplicationRequest r = requestRepo.findById(id).orElseThrow();
        Operator op = operatorRepo.findById(operatorId).orElseThrow();
        r.getOperators().remove(op);
        requestRepo.save(r);
        ra.addFlashAttribute("msg", "Operator removed from request.");
        return "redirect:/requests/" + id;
    }
}
