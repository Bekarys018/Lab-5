package com.example.requests;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class CourseController {
    private final CourseRepository courseRepo;

    @GetMapping("/courses")
    public String list(Model model){
        model.addAttribute("courses", courseRepo.findAll());
        return "courses";
    }
}
