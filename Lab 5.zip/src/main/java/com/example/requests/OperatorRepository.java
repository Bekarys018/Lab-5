package com.example.requests;
import org.springframework.data.jpa.repository.JpaRepository;
public interface OperatorRepository extends JpaRepository<Operator, Long> {}
